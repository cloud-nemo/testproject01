<?php
/**
 * autoload.php
 */
/**
 * PHPs default __autload
 * Grabs an instance of ServiceLocator then runs it
 * http://php.net/manual/en/language.oop5.autoload.php
 * @author Chris Corbyn
 * @param string $class
 */
require 'Autoloader/ServiceLocator.php';
//require 'Autoloader/Locator/ILocator.php';
//require 'Autoloader/Locator/AbstractServiceLocator.php';
function __autoload($class)
{
    $locator = new \Autoloader\ServiceLocator();
    $locator->load($class);
}

// An example Use Case:

//require 'Autoloader/ServiceLocator.php';
//
////Define some sort of service locator to attach...
//class PearLocator implements Autoloader\Locator\ILocator
//{
//    protected $_base = '.';
//
//    public function __construct($directory = '.')
//    {
//        $this->_base = (string) $directory;
//    }
//
//    public function canLocate($class)
//    {
//        $path = $this->getPath($class);
//        if (file_exists($path)) {
//            return true;
//        }
//        return false;
//    }
//
//    public function getPath($class)
//    {
//        return $this->_base . '/' . str_replace('_', '/', $class) . '.php';
//    }
//}
//
//// ... attach it ...
//Autoloader\ServiceLocator::attachLocator(new PearLocator(), 'PEAR');
//
//// ... and code away....
//$foo = new Foo_Test();