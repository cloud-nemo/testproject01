<?php
/**
 * ServiceLocator.php
 */
/**
 * Autoloader\ServiceLocator
 *
 * The main service locator.
 * Uses loosely coupled locators in order to operate
 *
 * http://php.net/manual/en/language.oop5.autoload.php
 * @package Autoloader
 * @author Chris Corbyn
 */
namespace Autoloader;

class ServiceLocator
{
    /**
     * Contains any attached service locators
     * @var array Locator
     */
    protected static $_locators = array();

    /**
     * Attach a new type of locator
     * @param Locator\ILocator $locator
     * @param object Locator\ILocator
     */
    public static function attachLocator(Locator\ILocator $locator, $key)
    {
        self::$_locators[$key] = $locator;
    }

    /**
     * Remove a locator that's been added
     * @param string $key
     * @return bool
     */
    public static function dropLocator($key)
    {
        if (self::isActiveLocator($key)) {
            unset(self::$_locators[$key]);
            return true;
        }
        return false;
    }

    /**
     * Check if a locator is currently loaded
     * @param string $key
     * @return bool
     */
    public static function isActiveLocator($key)
    {
        return array_key_exists($key, self::$_locators);
    }

    /**
     * loads configuration values and attaches defined autoloading modules/libraries
     * @param array $config
     */
    public static function loadConfig($config)
    {
        foreach ($config as $typeKey => $typeValues) {
            foreach ($typeValues as $key => $values) {
                $locPath = $typeKey . DIRECTORY_SEPARATOR . $key . DIRECTORY_SEPARATOR . $values['locator'] . '.php';
                if (!class_exists($values['locator'])
                    && file_exists($locPath)
                ) {
                    require_once $locPath;
                }
                try {
                    $locator = new $values['locator']($values['base_path'], $values['class_dir_separator']);
                    self::attachLocator($locator, $key);
                } catch (\RuntimeException $e) {
                    error_log('Failed to initialize ServiceLocator "' . $values['locator'] . '" ' . PHP_EOL .
                        'Error: ' . $e->getMessage());
                }
            }
        }
    }

    /**
     * Load in the required service by asking all service locators
     * @param string $class
     */
    public function load($class)
    {
        foreach (self::$_locators as $obj) {
            if ($obj->canLocate($class)) {
                $path = $obj->getPath($class);
                require $path;
                if (class_exists($class)) {
                    return;
                }
            }
        }
    }

}
