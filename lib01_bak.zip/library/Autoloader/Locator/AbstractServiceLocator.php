<?php
/**
 * AbstractServiceLocator.php
 * @copyright Copyright © 2015 Unister Travel Betriebsgesellschaft mbH
 * @author    Unister Travel Betriebsgesellschaft mbH <entwicklung@unister.de>
 */
/**
 * AbstractServiceLocator
 *
 * @copyright Copyright © 2015 cloud-nemo
 * @author    cloud-nemo
 */
namespace Autoloader\Locator;

abstract class AbstractServiceLocator implements ILocator
{
    protected $_base;

    private $_pathSeparator;

    public function __construct($baseDir, $pathSeparator)
    {
        $this->_base = (string)$baseDir;
        $this->_pathSeparator = (string)$pathSeparator;
    }

    public function canLocate($class)
    {
        $path  = $this->getPath($class);
        if (file_exists($path)) {
            return true;
        }
        return false;
    }

    public function getPath($class)
    {
        return $this->_base . '/' . str_replace($this->_pathSeparator, '/', $class) . '.php';
    }
}
