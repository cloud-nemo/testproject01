<?php
/**
 * application.config.php
 *
 * @copyright Copyright © 2015 cloud-nemo
 * @author    cloud-nemo
 */
return array(
    'library' => array(
        // define autoloader paths to the libraries
        /*'Autoloader' => array(
            'locator' => 'ServiceLocator',
            'base_path' => './library/Autoloader',
            'class_dir_separator' => '\\'
        )*/
    ),
    'module'   => array(
        // define autoloader paths to the modules
        'Website' => array(
            'locator' => 'WebsiteLocator',
            'base_path' => './module/Website',
            'class_dir_separator' => '\\'
        )
    )
);
