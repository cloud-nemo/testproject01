<?php
/**
 * Startpage.php
 * @copyright Copyright © 2015 Unister Travel Betriebsgesellschaft mbH
 * @author    Unister Travel Betriebsgesellschaft mbH <entwicklung@unister.de>
 */
/**
 * Startpage
 *
 * @package   Website
 *
 * @copyright Copyright © 2015 cloud-nemo
 * @author    cloud-nemo
 */
namespace Website;
class Startpage
{

    public static function callStartPage()
    {
        echo '<html><head><title>Start</title></head><body></body>';
    }
}
