<?php
/**
 * WebsiteLocator.php
 *
 * @copyright Copyright © 2015 cloud-nemo
 * @author    cloud-nemo
 */
/**
 * the modules ServcieLocator class
 * @package module
 */
namespace Website;
use \Autoloader\Locator\AbstractServiceLocator as AbstractLocator;
class WebsiteLocator extends AbstractLocator
{
}
