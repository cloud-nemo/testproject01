<?php
/**
 * index.php
 *
 * @copyright Copyright © 2015 cloud-nemo
 * @author    cloud-nemo
 */

chdir(dirname(__DIR__));

require 'library/autoload.php';

\Autoloader\ServiceLocator::loadConfig(require 'config/application.config.php');
\Website\Startpage::callStartPage();